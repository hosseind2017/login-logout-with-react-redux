import React from 'react';

class Greetings extends React.Component {
  render() {
    return (
      <div className="jumbotron">
        <h1>I Am Hossein</h1>
      </div>
    );
  }
}

export default Greetings;
